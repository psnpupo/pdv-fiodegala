const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_KEY || process.env.SUPABASE_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

exports.createUsuario = async (req, res) => {
  try {
    const { email, password, name, role, store_id } = req.body;

    // Validações básicas
    if (!email || !password || !name || !role) {
      return res.status(400).json({ 
        error: 'E-mail, senha, nome e role são obrigatórios.' 
      });
    }

    // Criar usuário no Supabase Auth
    const { data: authData, error: authError } = await supabase.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { name }
    });

    if (authError) {
      return res.status(400).json({ error: authError.message });
    }

    // Criar registro na tabela user_roles
    const { error: roleError } = await supabase
      .from('user_roles')
      .insert({
        user_id: authData.user.id,
        role,
        store_id: store_id || null,
        active: true
      });

    if (roleError) {
      // Se falhar ao criar role, deletar o usuário do Auth
      await supabase.auth.admin.deleteUser(authData.user.id);
      return res.status(500).json({ error: 'Erro ao criar role do usuário.' });
    }

    res.status(201).json({
      message: 'Usuário criado com sucesso!',
      user: {
        id: authData.user.id,
        email: authData.user.email,
        name,
        role,
        store_id
      }
    });

  } catch (err) {
    console.error('Erro ao criar usuário:', err);
    res.status(500).json({ error: 'Erro interno do servidor.' });
  }
};

exports.listUsuarios = async (req, res) => {
  try {
    const { data, error } = await supabase.auth.admin.listUsers();
    if (error) return res.status(400).json({ error: error.message });
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: 'Erro interno ao listar usuários.' });
  }
}; 

exports.updateUsuario = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, role, store_id, password, active } = req.body;

    // Atualizar dados do usuário no Auth
    const updateData = {
      user_metadata: { name }
    };

    if (password) {
      updateData.password = password;
    }

    const { data: authData, error: authError } = await supabase.auth.admin.updateUserById(id, updateData);

    if (authError) {
      return res.status(400).json({ error: authError.message });
    }

    // Atualizar role na tabela user_roles
    if (role !== undefined) {
      // Desativar roles antigas
      await supabase.from('user_roles').update({ active: false }).eq('user_id', id);
      
      // Criar nova role
      const { error: roleError } = await supabase
        .from('user_roles')
        .insert({
          user_id: id,
          role,
          store_id: store_id || null,
          active: active !== undefined ? active : true
        });

      if (roleError) {
        return res.status(500).json({ error: 'Erro ao atualizar role do usuário.' });
      }
    } else if (active !== undefined) {
      // Apenas atualizar o status active
      const { error: roleError } = await supabase
        .from('user_roles')
        .update({ active })
        .eq('user_id', id)
        .eq('active', !active);

      if (roleError) {
        return res.status(500).json({ error: 'Erro ao atualizar status do usuário.' });
      }
    }

    res.json({
      message: 'Usuário atualizado com sucesso!',
      user: {
        id: authData.user.id,
        email: authData.user.email,
        name,
        role,
        store_id,
        active
      }
    });

  } catch (err) {
    console.error('Erro ao atualizar usuário:', err);
    res.status(500).json({ error: 'Erro interno do servidor.' });
  }
};

exports.deleteUsuario = async (req, res) => {
  try {
    const { id } = req.params;

    // Deletar usuário do Auth
    const { error: authError } = await supabase.auth.admin.deleteUser(id);

    if (authError) {
      return res.status(400).json({ error: authError.message });
    }

    // Deletar roles da tabela user_roles
    await supabase.from('user_roles').delete().eq('user_id', id);

    res.json({ message: 'Usuário deletado com sucesso!' });

  } catch (err) {
    console.error('Erro ao deletar usuário:', err);
    res.status(500).json({ error: 'Erro interno do servidor.' });
  }
};

// Atribuir role a usuário
exports.assignRole = async (req, res) => {
  try {
    const { id } = req.params;
    const { role, store_id } = req.body;

    if (!role) {
      return res.status(400).json({ error: 'Role é obrigatória.' });
    }

    // Desativar roles antigas
    await supabase
      .from('user_roles')
      .update({ active: false })
      .eq('user_id', id);

    // Criar nova role
    const { error: roleError } = await supabase
      .from('user_roles')
      .insert([{
        user_id: id,
        role: role,
        store_id: store_id || null,
        active: true
      }]);

    if (roleError) {
      console.error('Erro ao atribuir role:', roleError);
      return res.status(500).json({ error: 'Erro ao atribuir role ao usuário.' });
    }

    res.json({ message: 'Role atribuída com sucesso!' });

  } catch (err) {
    console.error('Erro ao atribuir role:', err);
    res.status(500).json({ error: 'Erro interno do servidor.' });
  }
}; 