ALTER TABLE users ADD COLUMN auth_id uuid;
