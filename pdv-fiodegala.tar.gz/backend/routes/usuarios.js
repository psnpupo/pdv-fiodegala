const express = require('express');
const router = express.Router();
const { createUsuario, listUsuarios, updateUsuario, deleteUsuario, assignRole } = require('../controllers/usuariosController');

router.post('/', createUsuario);
router.get('/', listUsuarios);
router.put('/:id', updateUsuario);
router.delete('/:id', deleteUsuario);
router.post('/:id/role', assignRole);

module.exports = router; 