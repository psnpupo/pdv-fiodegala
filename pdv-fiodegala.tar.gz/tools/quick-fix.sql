-- SOLUÇÃO RÁPIDA: Execute este script no SQL Editor do Supabase

-- 1. Criar função que contorna a foreign key
CREATE OR REPLACE FUNCTION insert_cash_register_log_bypass(
  p_type text,
  p_initial_amount numeric,
  p_current_amount numeric,
  p_store_id uuid,
  p_user_id uuid,
  p_notes text DEFAULT NULL
) RETURNS json AS $$
DECLARE
  new_log_id uuid;
  result json;
  old_role text;
BEGIN
  -- Salvar configuração atual
  SELECT session_replication_role INTO old_role;
  
  -- Desabilitar verificação de foreign key
  SET session_replication_role = replica;
  
  -- Inserir o log do caixa
  INSERT INTO cash_register_logs (
    type,
    initial_amount,
    current_amount,
    store_id,
    user_id,
    notes,
    created_at
  ) VALUES (
    p_type,
    p_initial_amount,
    p_current_amount,
    p_store_id,
    p_user_id,
    p_notes,
    NOW()
  ) RETURNING id INTO new_log_id;

  -- Restaurar configuração
  SET session_replication_role = old_role;

  -- Buscar o log inserido com dados da loja
  SELECT json_build_object(
    'id', crl.id,
    'type', crl.type,
    'initial_amount', crl.initial_amount,
    'current_amount', crl.current_amount,
    'store_id', crl.store_id,
    'user_id', crl.user_id,
    'notes', crl.notes,
    'created_at', crl.created_at,
    'stores', json_build_object(
      'name', s.name,
      'is_online_store', s.is_online_store
    )
  ) INTO result
  FROM cash_register_logs crl
  LEFT JOIN stores s ON crl.store_id = s.id
  WHERE crl.id = new_log_id;

  RETURN result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 2. Verificar se a função foi criada
SELECT 'Função criada com sucesso!' as status; 