-- Remover tabela users não utilizada e corrigir foreign keys
-- Este script deve ser executado no SQL Editor do Supabase

-- 1. Remover a foreign key constraint problemática
DO $$ 
BEGIN
    IF EXISTS (
        SELECT 1 FROM information_schema.table_constraints 
        WHERE constraint_name = 'cash_register_logs_user_id_fkey' 
        AND table_name = 'cash_register_logs'
    ) THEN
        ALTER TABLE cash_register_logs DROP CONSTRAINT cash_register_logs_user_id_fkey;
    END IF;
END $$;

-- 2. Verificar se existem outras foreign keys para a tabela users
SELECT 
    tc.constraint_name,
    tc.table_name,
    kcu.column_name
FROM information_schema.table_constraints AS tc
JOIN information_schema.key_column_usage AS kcu
    ON tc.constraint_name = kcu.constraint_name
    AND tc.table_schema = kcu.table_schema
WHERE tc.constraint_type = 'FOREIGN KEY' 
    AND ccu.table_name = 'users';

-- 3. Remover a tabela users (se não houver outras dependências)
DROP TABLE IF EXISTS users CASCADE;

-- 4. Adicionar nova foreign key para auth.users (opcional, para manter integridade)
ALTER TABLE cash_register_logs 
ADD CONSTRAINT cash_register_logs_user_id_fkey 
FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;

-- 5. Verificar se tudo está funcionando
SELECT 
    tc.constraint_name,
    tc.table_name,
    kcu.column_name,
    ccu.table_name AS foreign_table_name,
    ccu.column_name AS foreign_column_name
FROM information_schema.table_constraints AS tc
JOIN information_schema.key_column_usage AS kcu
    ON tc.constraint_name = kcu.constraint_name
    AND tc.table_schema = kcu.table_schema
JOIN information_schema.constraint_column_usage AS ccu
    ON ccu.constraint_name = tc.constraint_name
    AND ccu.table_schema = tc.table_schema
WHERE tc.constraint_type = 'FOREIGN KEY' 
    AND tc.table_name = 'cash_register_logs'
    AND kcu.column_name = 'user_id'; 