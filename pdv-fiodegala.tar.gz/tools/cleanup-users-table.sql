-- Limpeza da tabela users não utilizada
-- Execute este script no SQL Editor do Supabase

-- 1. Remover foreign key constraint problemática
ALTER TABLE cash_register_logs DROP CONSTRAINT IF EXISTS cash_register_logs_user_id_fkey;

-- 2. Remover a tabela users (não está sendo usada)
DROP TABLE IF EXISTS users CASCADE;

-- 3. Adicionar foreign key correta para auth.users
ALTER TABLE cash_register_logs 
ADD CONSTRAINT cash_register_logs_user_id_fkey 
FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;

-- 4. Verificar se está funcionando
SELECT 'Foreign key corrigida com sucesso!' as status; 